document.getElementById('postForm').addEventListener('submit', async function(event) {
    event.preventDefault(); // Previne o envio padrão do formulário

    const Titulo = document.getElementById('titulo').value;
    const Conteudo = document.getElementById('conteudo').value;

    try {
        const response = await fetch('http://localhost:3000/submit-post', { // Altere a URL se seu backend estiver em outro lugar
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ Titulo, Conteudo })
        });

        const result = await response.json();
        document.getElementById('message').textContent = result.message;
        if (response.ok) {
            document.getElementById('message').style.color = 'green';
            document.getElementById('postForm').reset(); // Limpa o formulário
        } else {
            document.getElementById('message').style.color = 'red';
        }

    } catch (error) {
        console.error('Erro ao enviar o formulário:', error);
        document.getElementById('message').textContent = 'Erro ao conectar com o servidor.';
        document.getElementById('message').style.color = 'red';
    }
});